﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Sistema_completo
{
    class Usuarios
    {
        private string nome;
        private string cpf;
        private string email;
        private string usua;
        private string senha;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Usua
        {
            get { return usua; }
            set { usua = value; }
        }
        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public bool CadastrarUser()
        {
            try
            {
                if (!CpfValido(Cpf))
                {
                    MessageBox.Show("CPF inválido. Por favor, insira um CPF válido.");
                    return false;
                }

                if (!verificarEmail(Email))
                {
                    MessageBox.Show("Email inválido. Por favor, insira um Email válido.");
                    return false;
                }

                if (UsuarioExiste())
                {
                    MessageBox.Show("usuario já existente");
                    return false;

                }
                string senhaCriptografada = CriptografarSenha(Senha);

                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string inserir = "insert into usuarios (nome, cpf, email, nome_usuario, senha) values (@nome, @cpf, @email, @nome_usuario, @senha);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@email", Email);
                    comando.Parameters.AddWithValue("@nome_usuario", Usua);
                    comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                    int resultado = comando.ExecuteNonQuery();

                    return resultado > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro (na classe Usuarios) ao realizar cadastro: " + ex.Message);
                return false;
            }
        }

        public static string CriptografarSenha(string senha)
        {
            try
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha ?? ""));
                    StringBuilder builder = new StringBuilder();
                    foreach (byte b in bytes)
                        builder.Append(b.ToString("x2"));
                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível criptografar a senha: " + ex.Message, "Erro - Método Criptografar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "";
            }
        }

        public static bool CpfValido(string cpf)
        {
            if (string.IsNullOrWhiteSpace(cpf))
                return false;

            cpf = new string(cpf.Where(char.IsDigit).ToArray());

            if (cpf.Length != 11 || cpf.Distinct().Count() == 1)
                return false;

            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += (cpf[i] - '0') * (10 - i);
            int resto = soma % 11;
            int digito1 = resto < 2 ? 0 : 11 - resto;

            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += (cpf[i] - '0') * (11 - i);
            resto = soma % 11;
            int digito2 = resto < 2 ? 0 : 11 - resto;

            return cpf[9] - '0' == digito1 && cpf[10] - '0' == digito2;
        }

        public static bool verificarEmail(string email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(email);
        }

        public bool UsuarioExiste()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "SELECT COUNT(*) FROM usuarios WHERE cpf = @cpf OR email = @email OR nome_usuario = @nome_usuario";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@email", Email);
                    comando.Parameters.AddWithValue("@nome_usuario", Usua);

                    long resultado = (long)comando.ExecuteScalar();
                    if (resultado > 0)
                    {
                        return true;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao verificar existência do usuário: " + ex.Message);
                return false;
            }
            return false;
        }

        public bool AlterarSenha(string email, string novaSenha)
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string novaSenhaCriptografada = CriptografarSenha(novaSenha);

                    string query = "UPDATE usuarios SET senha = @senha WHERE email = @email";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@senha", novaSenhaCriptografada);
                    comando.Parameters.AddWithValue("@email", email);

                    int linhasAfetadas = comando.ExecuteNonQuery();
                    if(linhasAfetadas > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao alterar a senha: " + ex.Message);
                return false;
            }
        }

        public bool Logar(string identificador, string senha)
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string senhaCriptografada = CriptografarSenha(senha);

                    string query = @"SELECT COUNT(*) FROM usuarios 
                             WHERE (email = @Identificador OR nome_usuario = @Identificador) 
                             AND senha = @Senha";

                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@Identificador", identificador);
                    comando.Parameters.AddWithValue("@Senha", senhaCriptografada);

                    long resultado = (long)comando.ExecuteScalar();
                    if(resultado > 0)
                    {
                        return true;    
                    }
                    else
                    {
                        return false;   
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar fazer login: " + ex.Message);
                return false;
            }
        }




    }
}
