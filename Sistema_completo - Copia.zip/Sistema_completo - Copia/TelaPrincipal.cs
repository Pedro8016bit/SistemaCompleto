﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;

namespace Sistema_completo
{
    public partial class TelaPrincipal : UserControl
    {
        Produtos produto = new Produtos();

        public TelaPrincipal()
        {
            InitializeComponent();
        }

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            produto.Nome_produto = txt_nome_produto.Text;
            produto.Quantidade = txt_quantidade.Text;
            produto.Preco = txt_preco.Text;
            produto.Categoria = cmb_categoria2.Text;

            if (string.IsNullOrWhiteSpace(txt_nome_produto.Text) || string.IsNullOrWhiteSpace(txt_preco.Text) || txt_quantidade.Value <= 0)
            {
                MessageBox.Show("Preencha os campos corretamente");
            }
            else
            {
                bool CadSucesso = produto.Inserir_produtos();

                if (CadSucesso)
                {
                    CarregarProdutos();
                    MessageBox.Show("Cadastro realizado com sucesso!");
                }
            }

        }

        private void CarregarCategorias()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "SELECT nome_categoria FROM categorias ORDER BY nome_categoria";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    MySqlDataReader leitor = comando.ExecuteReader();

                    cmb_categoria1.Items.Clear();
                    cmb_categoria2.Items.Clear(); // Limpa a ComboBox antes de preencher

                    while (leitor.Read())
                    {
                        cmb_categoria1.Items.Add(leitor["nome_categoria"].ToString());
                        cmb_categoria2.Items.Add(leitor["nome_categoria"].ToString());
                    }

                    if (cmb_categoria1.Items.Count > 0)
                    {
                        cmb_categoria1.SelectedIndex = 0;
                    }
                    if (cmb_categoria2.Items.Count > 0)
                    {
                        cmb_categoria2.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar categorias: " + ex.Message);
            }
        }
        private void CarregarProdutos()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = @"
                SELECT p.id_produto, p.nome, p.quantidade, p.preco, c.nome_categoria AS categoria 
                FROM produtos p
                INNER JOIN categorias c ON p.categoria = c.id_categoria
                ORDER BY p.nome";

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(query, conexao);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    dataGrid.DataSource = tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar produtos: " + ex.Message);
            }
        }


        private void TelaPrincipal_Load(object sender, EventArgs e)
        {
            CarregarCategorias();
            CarregarProdutos();
        }
    }
}
